import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-look-for-account',
  templateUrl: './look-for-account.component.html',
  styleUrls: ['./look-for-account.component.css']
})
export class LookForAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
