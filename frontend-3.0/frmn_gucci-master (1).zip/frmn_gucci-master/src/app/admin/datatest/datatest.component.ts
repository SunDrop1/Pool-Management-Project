import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datatest',
  templateUrl: './datatest.component.html',
  styleUrls: ['./datatest.component.css']
})
export class DatatestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
