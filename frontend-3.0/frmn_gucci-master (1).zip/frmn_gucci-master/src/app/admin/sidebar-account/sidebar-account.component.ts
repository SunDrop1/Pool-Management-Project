import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-account',
  templateUrl: './sidebar-account.component.html',
  styleUrls: ['./sidebar-account.component.css']
})
export class SidebarAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
