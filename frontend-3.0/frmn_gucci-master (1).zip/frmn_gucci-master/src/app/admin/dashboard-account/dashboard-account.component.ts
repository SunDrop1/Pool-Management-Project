import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-account',
  templateUrl: './dashboard-account.component.html',
  styleUrls: ['./dashboard-account.component.css']
})
export class DashboardAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
